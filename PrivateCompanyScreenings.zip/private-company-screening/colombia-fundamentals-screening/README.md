# Fundamentals-Based Screening and Ranking of Private Companies in Colombia

*Revision 2 — updated after correcting data-extraction and methodology issues found during
implementation; see Sections 4 and 5.*

## Objective

This project builds a fundamentals-based screening and ranking framework for private companies
in Colombia, using observable company characteristics derived from financial statements and
sector classifications. The methodology adapts concepts commonly used in public equity factor
investing (quality, value, and risk factors) to a private-markets context, where standardized
financial statement data submitted to the Superintendencia de Sociedades is the primary
available information.

The output is a cross-sectional ranking of firms by fundamental quality, safety, and asset
backing, a screened set of top-ranked holdings with sector-capped weights, and a separate broad
economic-sector allocation view. **It is not a validated expected-return model** and does not
claim to forecast which firms will outperform going forward — there is no return series in this
dataset against which such a claim could be tested.

## Data

Financial statement data for Colombian companies from the Superintendencia de Sociedades
(Supersociedades), which requires thousands of Colombian companies to submit standardized
financial statements using an IFRS-based XBRL taxonomy.

- **Balance sheet:** total assets, PP&E, intangible assets, liabilities, payables
- **Income statement:** revenue, operating income, EBITDA proxies, interest expenses
- **Firm characteristics:** sector classification (CIIU code), company identifier (NIT)

### Data limitations

1. **Lack of market prices.** Private firms aren't publicly traded, so returns can't be
   observed, volatility can't be estimated from price movements, and there is no outcome
   variable against which any "expected return" proxy — or any data-driven factor weighting —
   can be validated. This surfaced concretely during implementation (Section 5.2 below).
2. **Limited time series depth.** Most companies report a single fiscal-year snapshot
   (FY2024). Every metric here is a point-in-time cross-sectional comparison, not a track record.
3. **Missing or sparse variables.** Financing costs, overdue payables, and leverage differences
   contain many missing values or limited dispersion for some firms.
4. **Accounting heterogeneity.** Private firms may differ in reporting standards, timing of
   revenue/expense recognition, or treatment of intangible assets.
5. **Rollforward structure in note-level filings.** The supporting note filings (PP&E,
   intangibles, payables, revenue) are quarterly rollforward schedules, not single point-in-time
   facts — see the next section for the issue this caused and the fix applied.

## Data structure issues identified and corrected

A review of the underlying Supersociedades filings surfaced a structural issue in how the
supporting note tables (PP&E, intangibles, payables, revenue) were aggregated to one value per
company.

**The issue:** each note table is a long-format rollforward — every company has multiple rows
per quarter, tagged by a `Concepto` field, all writing into the same numeric column (e.g. a
beginning balance, additions, disposals, depreciation, and an ending balance for PP&E, all in
one column). The original extraction aggregated each table with a company-level `max()` or
`sum()`, without filtering to a specific `Concepto` or matching the note's date to the balance
sheet's own reporting date:

- **PP&E / intangibles (`max()`):** a beginning-of-quarter balance is not always smaller than
  that quarter's ending balance, so `max()` across all rollforward line items and all quarters
  could silently select a stale or non-final figure.
- **Payables (`sum()`):** the value column contains a grand total and its own subcomponents
  simultaneously in the same quarter, so summing across all `Concepto` rows added the total to
  its own parts, compounded across four quarters — this directly affects
  `payables_past_due_share`, a safety-score input.
- **Revenue (`max()`):** quarterly figures are not cumulative or monotonic, so `max()` across
  quarters could select a single quarter's revenue rather than the fiscal-year total.

**The fix:** filter each note table to the single correct `Concepto` (end-of-period balance for
PP&E/intangibles; the grand-total line for revenue; the two named current/non-current total rows,
excluding their sub-lines, for payables) and match on NIT + `Fecha de Corte`, keeping each
company's most recent reporting date.

**Verification:** post-fix, `ppe_total` and `intangibles_total` floor at 0 (previously as low as
−584,573 and −8,405 respectively — a balance-sheet asset category cannot be negative), and
`ppe_to_assets` / `intangibles_to_assets` now cap just under 1.0 (previously as high as 2.22 and
3.72 — a single asset subcategory cannot exceed 100% of total assets). Both checks confirm the
fix resolved the aggregation error rather than merely changing the numbers.

## Methodology issues identified and corrected during implementation

Three further issues emerged while building the factor- and sector-weighting logic on top of the
corrected data. Documented here because each materially changed the results, and because the
diagnostic process is itself informative about the limits of this dataset.

### Selection circularity in factor and sector diagnostics

The pipeline selects a top-N subset of companies by `score_net` before reporting which factors
or sectors appear most "important." Computing factor/sector statistics on that already-selected
subsample is circular: firms were selected because their scores were high on certain factors, so
re-measuring factor strength on that subsample overstates the importance of the factors used to
select it. **Fix:** separate the selection step from the diagnostic step — a full-universe
snapshot (`df_full`) is taken immediately after `score_net` is computed but before any
filtering, and all factor/sector-importance diagnostics run against that full-universe snapshot.

### A data-driven "signal-to-noise" factor weighting is not identifiable from this dataset

The original design weighted each factor by a signal-to-noise ratio: the cross-sectional mean of
that factor's z-score, divided by its standard deviation, computed on the same population the
z-scores were standardized against. Once the circularity above was corrected, this calculation
was verified directly: on the full universe, **every factor's mean z-score is 0 to within
floating-point precision**, and every standard deviation is exactly 1.0. This is not a data
quality issue — it's a mathematical identity: a z-score is `(value − population mean) /
population standard deviation`, so the mean of a z-scored variable over that same population is
0 by construction, for every factor, regardless of whether that factor is economically
meaningful. A signal-to-noise ratio computed this way cannot distinguish an important factor
from an unimportant one.

**Fix:** rather than retain a computation that looks data-driven but is provably degenerate, the
signal-to-noise factor weighting was removed. In its place, the analysis uses fixed weights
chosen on economic-intuition grounds, disclosed explicitly below.

### Sign-flip in broad-sector allocation from an unclipped negative denominator

The broad-sector (macro-bucket) allocation computes sector "strength" as
`mean(score) × sqrt(number of firms)`, then normalizes by dividing each sector's strength by the
sum of all sectors' strength. Several broad sectors have a negative average `score_net`, so the
sum of strengths across all sectors can itself be negative — **dividing by a negative denominator
flips every sign**: sectors with the most negative average scores received the largest positive
weights, and the sector with the best average score received a negative weight. This was caught
by inspecting a results table where the ranking by weight was the reverse of the ranking by
score. **Fix:** floor negative sector strength at 0 before normalizing, so a sector with a
negative average score receives zero weight rather than a distorted one.

## Methodology

**Factor construction:** firm characteristics are transformed into standardized variables using
z-scores, `z = (value − mean) / standard deviation`, expressing each firm's metric relative to
the cross-sectional distribution of firms in the sample.

**Economic intuition for selected factors:** profitability (operating margin, ROA), liquidity
(current ratio), leverage (debt-to-assets, interest coverage proxy), asset backing
(PP&E-to-assets), distress (share of overdue payables).

**Two parallel scoring systems**, both using fixed, disclosed weights:
- `quality_score` / `safety_score` / `value_score` / `total_score` — an equal-weighted top-30
  reference ranking.
- `mu_proxy` (fundamental strength indicator) / `risk_proxy` (risk indicator) / `score_net` —
  used to select and weight the actual candidate portfolio.

**Fundamental strength indicator (`mu_proxy`):** since market returns are unavailable, this
proxies fundamental strength — *not* expected return — using a fixed-weight composite of
profitability, liquidity, asset backing, and interest coverage z-scores. This is an assumption
grounded in general corporate finance intuition, not an empirically estimated relationship
between these characteristics and realized returns.

**Risk indicator (`risk_proxy`):** proxied using leverage intensity, overdue-payables share, and
financing cost burden. A characteristic-based heuristic, not a statistically estimated risk
measure — there is no covariance matrix across firms underlying this indicator.

**Company-level selection and sector-capped weighting:** companies with positive `score_net` are
ranked and the top 50 retained as the candidate portfolio. Weights are proportional to
`score_net`, capped at 8% per company and 25% per CIIU sector code (the fine-grained, ~400-category
classification), then renormalized.

**Broad-sector (macro-bucket) allocation:** every company's CIIU code is mapped into one of nine
broad economic buckets (real estate, agriculture, energy/mining, manufacturing, trade,
professional services, technology, construction, other) using the leading CIIU letter.
Bucket-level strength is `mean(score_net) × sqrt(number of firms in bucket)`, floored at 0, and
normalized. This is a separate, coarser lens on the same full universe — not the sector cap
applied to the company-level portfolio, and the two should not be read as the same allocation at
different levels of detail.

## Disclosed factor and score weights

Fixed, researcher-chosen values grounded in economic intuition, not empirically estimated (see
above for why a data-driven weighting was not identifiable from this dataset).

| Scoring system | Component | Weight |
|---|---|---|
| `quality_score` | operating margin | 0.25 |
| `quality_score` | ROA | 0.20 |
| `quality_score` | current ratio | 0.15 |
| `quality_score` | interest coverage | 0.15 |
| `quality_score` | debt-to-assets (neg.) | 0.15 |
| `quality_score` | past-due payables (neg.) | 0.10 |
| `safety_score` | debt-to-assets (neg.) | 0.35 |
| `safety_score` | past-due payables (neg.) | 0.25 |
| `safety_score` | finance cost burden (neg.) | 0.20 |
| `safety_score` | current ratio | 0.20 |
| `value_score` | PP&E-to-assets | 0.50 |
| `value_score` | ROA | 0.50 |
| `total_score` | quality_score | 0.50 |
| `total_score` | safety_score | 0.30 |
| `total_score` | value_score | 0.20 |
| `mu_proxy` | operating margin | 0.30 |
| `mu_proxy` | ROA | 0.25 |
| `mu_proxy` | current ratio | 0.15 |
| `mu_proxy` | PP&E-to-assets | 0.15 |
| `mu_proxy` | interest coverage | 0.15 |
| `risk_proxy` | debt-to-assets | 0.50 |
| `risk_proxy` | payables risk | 0.30 |
| `risk_proxy` | financing cost | 0.20 |
| `score_net` | mu_proxy | 1.00 |
| `score_net` | risk_proxy (risk aversion) | −0.70 |

## Company-level portfolio results (top holdings)

The 15 largest positions in the sector-capped, top-50 candidate portfolio:

| Company | CIIU sector | mu_proxy | risk_proxy | score_net | Weight |
|---|---|---|---|---|---|
| Inversiones OEM S.A.S. | M7490 — Prof./scientific/technical | 2.861 | −0.702 | 3.352 | 5.78% |
| Venise SAS | M7490 — Prof./scientific/technical | 1.737 | −0.702 | 2.229 | 3.85% |
| Sistemas Constructivos Avanzados ZF | C2229 — Plastics mfg. | 1.726 | −0.622 | 2.161 | 3.73% |
| Inversiones Avofruit SAS | M7010 — Business administration | 1.420 | −0.671 | 1.890 | 3.26% |
| Promotora y Comercializadora Turistica | I5511 — Hotels | 1.935 | 0.110 | 1.858 | 3.21% |
| Plural Comunicaciones SAS | J6020 — TV broadcasting | 2.020 | 0.249 | 1.846 | 3.19% |
| Inversiones en Inmuebles AC SAS | L6810 — Real estate | 1.406 | −0.452 | 1.722 | 2.97% |
| Centros Comerciales del Cafe SAS | L6810 — Real estate | 1.281 | −0.582 | 1.689 | 2.91% |
| Industrial Taylor SAS | G4659 — Wholesale machinery/equip. | 1.115 | −0.619 | 1.548 | 2.67% |
| Akrop Capital SAS | M7020 — Management consulting | 1.573 | 0.110 | 1.496 | 2.58% |
| Centro de Mecanizados del Cauca | M7010 — Business administration | 1.452 | 0.110 | 1.375 | 2.37% |
| Pactia SAS | K6630 — Fund administration | 0.928 | −0.586 | 1.338 | 2.31% |
| Nicomar Electronics S.A.S | G4659 — Wholesale machinery/equip. | 0.666 | −0.701 | 1.157 | 2.00% |
| Riopaila Palma S.A.S. | A0126 — Palm oil cultivation | 1.202 | 0.072 | 1.151 | 1.99% |
| Dexco Zona Franca S.A.S | C1620 — Wood panel mfg. | 0.668 | −0.671 | 1.138 | 1.96% |

The top 15 alone span eleven distinct CIIU industries — the 25% fine-grained sector cap is doing
its job, spreading the portfolio well beyond what the broad-bucket view below suggests.

## Broad-sector (macro-bucket) allocation results

| Broad sector | Avg. score | # Companies | Strength | Weight |
|---|---|---|---|---|
| Professional Services | 0.2113 | 197 | 2.9663 | 53.05% |
| Manufacturing | 0.0455 | 661 | 1.1710 | 20.94% |
| Real Estate | 0.0800 | 188 | 1.0974 | 19.63% |
| Technology | 0.0267 | 179 | 0.3569 | 6.38% |
| Agriculture | −0.0766 | 246 | 0.0000 | 0.00% |
| Other | −0.0389 | 428 | 0.0000 | 0.00% |
| Energy / Mining | −0.4685 | 130 | 0.0000 | 0.00% |
| Construction | −0.3811 | 241 | 0.0000 | 0.00% |
| Trade | −0.0358 | 834 | 0.0000 | 0.00% |

Five of the nine broad buckets — including Trade, the single largest bucket by company count at
834 firms — have a negative average score under this corrected methodology and are floored to
zero weight rather than assigned a distorted one.

## Economic interpretation of sector exposures

The broad-bucket allocation and the company-level holdings tell compatible but different
stories, and both should be read together rather than in isolation. At the broad-bucket level,
results concentrate in Professional Services, Manufacturing, Real Estate, and Technology — this
doesn't mean no company in the zero-weighted sectors was strong, only that the *average* firm in
those buckets scored negative. At the company level, the actual top-50 holdings remain spread
across many distinct CIIU industries (plastics manufacturing, hotels, TV broadcasting, real
estate, machinery wholesale, management consulting, fund administration, palm oil cultivation,
wood panel manufacturing, and more), because the 25% CIIU-level cap operates at much finer
granularity than the nine broad buckets. A portfolio can be well diversified across specific
industries while looking concentrated when those industries are grouped into a handful of broad
categories — the company-level portfolio is the more representative diversification picture; the
broad-bucket allocation is a useful summary lens but concentrates more than the underlying
holdings actually do.

- **Inflation sensitivity:** Real estate and manufacturing, both meaningfully weighted, provide
  exposure to real assets that tend to retain value during inflationary periods.
- **Commodity exposure:** direct exposure through Agriculture and Energy/Mining is limited in the
  current allocation, since firms in those sectors averaged a negative score in this sample —
  not a claim that commodity exposure is unimportant in Colombia generally.
- **Domestic growth / human capital:** Professional Services and Technology, together over half
  the broad-bucket weight, reflect firms that benefit from productivity growth and domestic
  economic activity rather than physical or commodity assets.
- **Financial resilience:** within the company-level holdings, firms with strong interest
  coverage and moderate leverage are, all else equal, less exposed to a tightening in credit
  conditions — visible in the `risk_proxy` column above, where most top holdings show negative
  (favorable) values.

## Strategy implications

Firms whose profitability, liquidity, and debt-servicing capacity stand out from peers score
highest under this fundamentals screen, measured without the circularity and sign-flip issues
that affected earlier results. What can no longer be claimed, after the signal-to-noise
diagnosis above, is that any particular factor is empirically "more important" than another —
that would require an outcome variable this dataset doesn't have. The weights used here are
disclosed assumptions, not estimated parameters.

This demonstrates that fundamentals-based screening techniques, adapted from public-market
factor investing, can be usefully applied to private company accounting data to rank and group
firms by observable characteristics — provided the underlying calculations are checked against
basic sanity constraints (asset ratios cannot exceed 1.0, weights cannot invert the ranking they
are meant to summarize, and a signal-to-noise calculation must be checked for whether it is
mathematically capable of producing a nonzero answer on the population it is run against). **It
does not demonstrate that the resulting ranking predicts future financial or investment
performance.**

## Improvements with additional data

The single clearest next step is a second period of financial data — with even one additional
fiscal year, it becomes possible to construct genuine outcome variables (year-over-year
survival, growth, fundamental improvement) against which factor weights could actually be
estimated rather than assumed. Beyond that: longer time series would support earnings volatility
estimates and cyclical sensitivity indicators; GARCH-type models could estimate firm earnings
volatility; rolling regressions could estimate sensitivity to interest rates, exchange rates, and
commodity prices; panel data would allow estimation of factor persistence and structural breaks.
If similar datasets become available across multiple countries, the methodology could extend to
cross-country factor effectiveness — but the prerequisite, in every direction this analysis could
grow, is the same one identified above: an outcome variable to test assumptions against, rather
than assume them.
